import java.net.*;
import java.io.*;

public class UDPMyEchoServerMultiThread {
	final int MAXBUFFER = 512;
	static DatagramSocket Dsocket;
	public static void main (String[] args) {
		int arg_port = Integer.parseInt(args[0]);// ��Ʈ ��ȣ
		try {
			Dsocket = new DatagramSocket(arg_port);//���� ����
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println ("Running the UDP Echo Server...");
		while(true){
			byte buffer[] = new byte[512];
			DatagramPacket recv_packet = new DatagramPacket(buffer, buffer.length);
			System.out.println("Server Ready");
			try {
				Dsocket.receive(recv_packet);//��Ŷ�� ������
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			receiveFrame r1 = new receiveFrame(Dsocket);//������ �����ϰ�
			r1.run(recv_packet);//�����忡 ��Ŷ�� �Ѱ���
		}
	}
}
	
		class receiveFrame extends Thread {
			DatagramSocket Dsocket;
			receiveFrame (DatagramSocket s) {
				Dsocket = s;
			}
			public void run(DatagramPacket recv_packet) {
					byte buffer[] = new byte[512];
					try {
						String str = new String(recv_packet.getData());
						System.out.println("���� �޼��� :" + str.trim());
						InetAddress ia = recv_packet.getAddress();
						int port = recv_packet.getPort();
						System.out.println("Client IP :" + ia + ", Client Port :" + port);
						DatagramPacket send_packet = new DatagramPacket(recv_packet.getData(), recv_packet.getData().length, ia, port);
						Dsocket.send (send_packet);
					} catch(IOException e) {
						System.out.println(e);}
			}
		} // end ReceiverThread class
